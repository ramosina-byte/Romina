ROMINA STATIC WEBSITE

Upload the entire contents of this folder to your web host / Cloudflare Pages.
The homepage is: index.html

Files:
- index.html
- assets/romina-tea.svg
- assets/romina-rice.svg

No build tools, frameworks, or external libraries are required.
Contact email used on the page: Contact@romina.fi
